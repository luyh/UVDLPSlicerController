﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UV_DLP_3D_Printer.GUI
{
    public partial class frmMain2 : Form
    {
        private enum eViewTypes
        {
            eV3d,
            eVSlice,
            eVControl,
            eVConfig
        }
        private eViewTypes m_viewtype;

        public frmMain2()
        {
            InitializeComponent();
            m_viewtype = eViewTypes.eV3d;
            HideAllViews();
            ShowView(eViewTypes.eV3d);
            RegisterCallbacks();
            SetButtonStatuses();
            UVDLPApp.Instance().AppEvent += new AppEventDelegate(AppEventDel);
            DebugLogger.Instance().LoggerStatusEvent += new LoggerStatusHandler(LoggerStatusEvent);
            UVDLPApp.Instance().Engine3D.UpdateGrid();
            ctl3DView1.UpdateView(); // initial update
            // set up initial log data in form
            foreach (string lg in DebugLogger.Instance().GetLog())
            {
                txtLog.Text = lg + "\r\n" + txtLog.Text;
            }
        }
        #region Delegate Event Handlers
        void LoggerStatusEvent(Logger o, eLogStatus status, string message)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { LoggerStatusEvent(o, status, message); }));
            }
            else
            {
                switch (status)
                {
                    case eLogStatus.eLogWroteRecord:
                        txtLog.Text = message + "\r\n" + txtLog.Text;
                        break;
                }
            }
        }
        /*
          This handles specific events triggered by the app
          */
        private void AppEventDel(eAppEvent ev, String Message)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { AppEventDel(ev, Message); }));
            }
            else
            {
                switch (ev)
                {
                    case eAppEvent.eModelNotLoaded:
                        DebugLogger.Instance().LogRecord(Message);
                        break;
                        /*
                    case eAppEvent.eModelRemoved:
                        //the current model was removed
                        DebugLogger.Instance().LogRecord(Message);
                        UpdateSceneInfo();
                        UVDLPApp.Instance().m_engine3d.UpdateLists();
                        ctl3DView1.UpdateView();
                        break;
                    case eAppEvent.eSlicedLoaded: // update the gui to view
                        DebugLogger.Instance().LogRecord(Message);
                        int totallayers = UVDLPApp.Instance().m_slicefile.NumSlices;
                        ctl3DView1.SetNumLayers(totallayers);
                        m_frmSliceView.SliceView.SetNumLayers(totallayers);
                        //show the slice in the slice view
                        ViewLayer(0, null, BuildManager.SLICE_NORMAL);
                        break;
                    case eAppEvent.eGCodeLoaded:
                        DebugLogger.Instance().LogRecord(Message);
                        m_frmGCode.GcodeView.Text = UVDLPApp.Instance().m_gcode.RawGCode;
                        break;
                    case eAppEvent.eGCodeSaved:
                        DebugLogger.Instance().LogRecord(Message);
                        break;
                    case eAppEvent.eModelAdded:
                        UpdateSceneInfo();
                        UVDLPApp.Instance().m_engine3d.UpdateLists();
                        //DisplayFunc();
                        ctl3DView1.UpdateView();
                        DebugLogger.Instance().LogRecord(Message);
                        break;
                    case eAppEvent.eSliceProfileChanged:
                        SetTitle();
                        break;
                    case eAppEvent.eMachineTypeChanged:
                        // FIXFIX : activate SetupForMachineType on 3dview control
                        SetupForMachineType();
                        SetTitle();
                        break;
                    case eAppEvent.eShowBlank:
                        showBlankDLP();
                        break;
                    case eAppEvent.eShowCalib:
                        showCalibrationToolStripMenuItem_Click(null, null);
                        break;
                    case eAppEvent.eShowDLP:
                        m_frmdlp.ShowDLPScreen();
                        break;
                    case eAppEvent.eHideDLP:
                        m_frmdlp.HideDLPScreen();
                        break;
                    case eAppEvent.eReDraw: // redraw the 3d display
                        //DisplayFunc();
                        ctl3DView1.UpdateView();
                        break;
                    case eAppEvent.eReDraw2D: // redraw the 2d layer of the 3d display
                        ctl3DView1.UpdateView(false);
                        break;
                    case eAppEvent.eUpdateSelectedObject:
                        UpdateSceneInfo();
                        break;
                    case eAppEvent.eMachineConnected:
                        showBlankDLP();
                        break;
                    case eAppEvent.eMachineDisconnected:
                        break;
                         * */
                }
                //Refresh();
            }

        }
        #endregion

        private void RegisterCallbacks() 
        {
            UVDLPApp.Instance().m_callbackhandler.RegisterCallback("ClickView3d", ctlTitle3dView_Click, null, "View 3d display");
            UVDLPApp.Instance().m_callbackhandler.RegisterCallback("ClickSliceView", ctlTitleViewSlice_Click, null, "View Slice display");
            UVDLPApp.Instance().m_callbackhandler.RegisterCallback("ClickManualCtlView", ClickManualCtlView_Click, null, "View Manual Machine Control");
            UVDLPApp.Instance().m_callbackhandler.RegisterCallback("ClickMainConfigView", ClickMainConfigView_Click, null, "View Main Configuration");
            //ctlMainManual1
        }

        private void HideAllViews() 
        {
            pnl3dview.Dock = DockStyle.None;
            pnl3dview.Visible = false;

            pnlSliceView.Dock = DockStyle.None;
            pnlSliceView.Visible = false;

            ctlMainManual1.Dock = DockStyle.None;
            ctlMainManual1.Visible = false;

            ctlMainConfig1.Dock = DockStyle.None;
            ctlMainConfig1.Visible = false;
        }
        private void ShowView(eViewTypes vt) 
        {
            m_viewtype = vt;
            switch (m_viewtype) 
            {
                case eViewTypes.eV3d:
                    pnl3dview.Dock = DockStyle.Fill;
                    pnl3dview.Visible = true;
                    break;
                case eViewTypes.eVConfig:
                    ctlMainConfig1.Dock = DockStyle.Fill;
                    ctlMainConfig1.Visible = true;
                    break;
                case eViewTypes.eVControl:
                    ctlMainManual1.Dock = DockStyle.Fill;
                    ctlMainManual1.Visible = true;
                    break;
                case eViewTypes.eVSlice:
                    pnlSliceView.Dock = DockStyle.Fill;
                    pnlSliceView.Visible = true;
                    break;
            }
        }
        #region button statuses
        private void SetButtonStatuses()
        {
            try
            {
                if (UVDLPApp.Instance().m_deviceinterface.Connected)
                {
                    buttConnect.Enabled = false;
                    buttDisconnect.Enabled = true;

                    if (UVDLPApp.Instance().m_buildmgr.IsPrinting)
                    {
                        if (UVDLPApp.Instance().m_buildmgr.IsPaused())
                        {
                            buttPlay.Enabled = true;
                            buttStop.Enabled = true;
                            buttPause.Enabled = false;
                        }
                        else
                        {
                            buttPlay.Enabled = false;
                            buttStop.Enabled = true;
                            buttPause.Enabled = true;
                        }
                    }
                    else
                    {
                        buttPlay.Enabled = true;
                        buttStop.Enabled = false;
                        buttPause.Enabled = false;
                    }
                }
                else
                {
                    buttConnect.Enabled = true;
                    buttDisconnect.Enabled = false;
                    buttPlay.Enabled = false;
                    buttStop.Enabled = false;
                    buttPause.Enabled = false;
                }
               // ctl3DView1.SetButtonStatus(buttConnect.Enabled, buttDisconnect.Enabled, buttPlay.Enabled, buttStop.Enabled, buttPause.Enabled);
                Refresh();
            }
            catch (Exception ex)
            {
                DebugLogger.Instance().LogError(ex.StackTrace);
            }
        }
        #endregion

        #region click handlers

        private void ClickMainConfigView_Click(object sender, object e)
        {
            HideAllViews();
            ShowView(eViewTypes.eVConfig);
        }

        private void ClickManualCtlView_Click(object sender, object e)
        {
            HideAllViews();
            ShowView(eViewTypes.eVControl);
        }
        private void ctlTitle3dView_Click(object sender, object e)
        {
            HideAllViews();
            ShowView(eViewTypes.eV3d);
        }
        private void ctlTitleViewSlice_Click(object sender, object e)
        {
            HideAllViews();
            ShowView(eViewTypes.eVSlice);
        }
        #endregion
    }
}
